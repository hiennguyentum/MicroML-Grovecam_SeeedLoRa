#pragma once

#include "kernels.h"


namespace Eloquent {
    namespace ML {

        /**
         *
         * @tparam D the number of features of each sample
         */
        template<unsigned int D>
        class SVMSMO {
        public:
            SVMSMO(kernelFunction kernel) :
                    _kernel(kernel),
                    _cache(NULL) {
                _params = {
                        .C = 1,
                        .tol = 1e-4,
                        .alphaTol = 1e-7,
                        .maxIter = 10000,
                        .passes = 10
                };
            }

            /**
             * Misclassification penalty
             * @param C
             */
            void setC(float C) {
                _params.C = C;
            }

            /**
             * Stop criterion tollerance
             * @param tol
             */
            void setTol(float tol) {
                _params.tol = tol;
            }

            /**
             * Leave out less influent support vectors
             * @param alphaTol
             */
            void setAlphaTol(float alphaTol) {
                _params.alphaTol = alphaTol;
            }

            /**
             * Set an upper bound to the number of iterations
             * @param maxIter
             */
            void setMaxIter(unsigned int maxIter) {
                _params.maxIter = maxIter;
            }

            /**
             *
             * @param passes
             */
            void setPasses(unsigned int passes) {
                _params.passes = passes;
            }

            /**
             *
             * @param cache
             */
            void setKernelCache(float *cache) {
                _cache = cache;
            }

            /**
             * Train the classifier
             * @param X
             * @param y
             * @param N num samples
             */
            void fit(float X[][D], int *y, unsigned int N) {
                _alphas = (float *) malloc(sizeof(float) * N);

                for (unsigned int i = 0; i < N; i++)
                    _alphas[i] = 0;

                unsigned int iter = 0;
                unsigned int passes = 0;

                // cache kernels
                if (_cache != NULL) {
                    for (unsigned int i = 0; i < N; i++) {
                        for (unsigned int j = 0; j < N; j++) {
                            _cache[i * N + j] = _kernel(X[i], X[j], D);
                        }
                    }
                }

                // train
                while(passes < _params.passes && iter < _params.maxIter) {
                    float alphaChanged = 0;

                    for (unsigned int i = 0; i < N; i++) {
                        float Ei = margin(X, y, X[i], N) - y[i];

                        if ((y[i] * Ei < -_params.tol && _alphas[i] < _params.C) || (y[i] * Ei > _params.tol && _alphas[i] > 0)) {
                            // alpha_i needs updating! Pick a j to update it with
                            unsigned int j = i;

                            while (j == i)
                                j = random(0, N);

                            float Ej = margin(X, y, X[j], N) - y[j];

                            // calculate L and H bounds for j to ensure we're in [0 _params.C]x[0 _params.C] box
                            float ai = _alphas[i];
                            float aj = _alphas[j];
                            float L = 0;
                            float H = 0;

                            if (y[i] == y[j]) {
                                L = max(0, ai + aj - _params.C);
                                H = min(_params.C, ai + aj);
                            } else {
                                L = max(0, aj - ai);
                                H = min(_params.C, _params.C + aj - ai);
                            }

                            if (abs(L - H) < 1e-4)
                                continue;

                            double eta;

                            if (_cache != NULL)
                                eta = _cache[i * N + j] - _cache[i * N + i] - _cache[j * N + j];
                            else {
                                eta = _kernel(X[i], X[j], D) - _kernel(X[i], X[i], D) - _kernel(X[j], X[j], D);
                            }

                            if (eta >= 0)
                                continue;

                            eta *= 2;

                            // compute new alpha_j and clip it inside [0 _params.C]x[0 _params.C] box
                            // then compute alpha_i based on it.
                            float newaj = aj - y[j] * (Ei - Ej) / eta;

//                            d("newaj", newaj);
//                            d("H", H);
//                            d("L", L);

                            if (newaj > H)
                                newaj = H;
                            if (newaj < L)
                                newaj = L;
                            if (abs(aj - newaj) < 1e-4)
                                continue;

                            float newai = ai + y[i] * y[j] * (aj - newaj);

                            _alphas[i] = newai;
                            _alphas[j] = newaj;

                            // update the bias term
                            float b1 = _b - Ei - y[i] * (newai - ai) * _kernel(X[i], X[i], D)
                                       - y[j] * (newaj - aj) * _kernel(X[i], X[j], D);
                            float b2 = _b - Ej - y[i] * (newai - ai) * _kernel(X[i], X[j], D)
                                       - y[j] * (newaj - aj) * _kernel(X[j], X[j], D);

                            _b = 0.5 * (b1 + b2);

                            if (newai > 0 && newai < _params.C)
                                _b = b1;
                            if (newaj > 0 && newaj < _params.C)
                                _b = b2;

                            alphaChanged++;
                        } // end alpha_i needed updating
                    } // end for i=1..N

                    iter++;

                    if(alphaChanged == 0)
                        passes++;
                    else passes= 0;
                }

                _y = y;
                _numSamples = N;
            }

            /**
             * Classify a new sample
             * @param x
             * @return
             */
            int predict(float X_train[][D], float x[D]) {
                return margin(X_train, _y, x, _numSamples, true) > 0 ? 1 : -1;
            }

            /**
             * Evaluate the accuracy of the classifier
             * @param X_train
             * @param X_test
             * @param y_test
             * @param testSize
             * @return
             */
            float score(float X_train[][D], float X_test[][D], int y_test[], unsigned int testSize) {
                unsigned int correct = 0;

                for (unsigned int i = 0; i < testSize; i++)
                    if (predict(X_train, X_test[i]) == y_test[i])
                        correct += 1;

                return 1.0 * correct / testSize;
            }

        protected:
            kernelFunction _kernel;
            struct {
                float C;
                float tol;
                float alphaTol;
                unsigned int maxIter;
                unsigned int passes;
            } _params;
            float _b = 0;
            unsigned int _numSamples;
            int *_y;
            float *_alphas;
            float *_cache;

            /**
             * Compute the margin of a new sample from the support vectors
             * @param X
             * @param y
             * @param x
             * @param N
             * @param skipSmallAlfas
             * @return
             */
            float margin(float X[][D], int *y, float x[D], unsigned int N, bool skipSmallAlfas = false) {
                float sum = _b;

                for(unsigned int i = 0; i < N; i++)
                    if ((!skipSmallAlfas && _alphas[i] != 0) || (skipSmallAlfas && _alphas[i] > _params.alphaTol))
                        sum += _alphas[i] * y[i] * _kernel(x, X[i], D);

                return sum;
            }
        };
    }
}