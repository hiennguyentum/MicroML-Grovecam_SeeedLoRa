Eloquent algorithms of Machine learning for microcontrollers.

Refer to the [intro blog post](https://eloquentarduino.github.io/2020/03/so-you-want-to-train-an-ml-classifier-directly-on-an-arduino-board/)
for the details.