#include "cv/DownsampledImage.h"
#include "cv/DownsampledImageComparator.h"
#include "cv/MotionDetector.h"