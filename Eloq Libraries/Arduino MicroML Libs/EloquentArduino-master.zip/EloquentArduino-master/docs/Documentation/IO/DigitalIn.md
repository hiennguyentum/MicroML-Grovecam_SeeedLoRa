---
title: DigitalIn
date: 2019-11-25
namespace: IO
template: doc
---

# IO::DigitalIn

A class to interact with digital input pins.

method|description
------|-----------
DigitalIn(uint8_t pin)|