class RVC:
    """Patch un-installed skbayes RVC classifier"""
    pass


class SEFR:
    """Patch un-installed SEFR classifier"""
    pass