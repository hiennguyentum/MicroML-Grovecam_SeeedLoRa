ARDUINO = 'arduino'
ATTINY = 'attiny'
ALL = [
    ARDUINO,
    ATTINY
]